var inlineAssessmentIdCounter = 0;
function InlineAssessment(elementArg) {
	//	static for class
	this.allTypes = {
		'wpm_test': "	Put your long HTML string here (escaping all \", of course)!!!	",
		'simple_text': "<input/><input type=\"button\" value=\"submit thingie\"/>"
	};
	this.type;
	this.id = inlineAssessmentIdCounter++;
	
	this.setElement = function( elementArg ) {
		this.emptyElement();
		if(!this.isElement(elementArg)) {
			console.log(typeof elementArg);
			throw 'Error (Inline Assessment): element must be a valid dom element.'; 
		}
		this.element = elementArg;
		this.setType( this.element );
		this.display( this.element );
		return this.element;
	};
	this.isElement = function(obj) {
		try {
			//Using W3 DOM2 (works for FF, Opera and Chrom)
			return obj instanceof HTMLElement;
		}
		catch(e){
			//Browsers not supporting W3 DOM2 don't have HTMLElement and
			//an exception is thrown and we end up here. Testing some
			//properties that all elements have. (works on IE7)
			return (typeof obj==="object") &&
				(obj.nodeType===1) && (typeof obj.style === "object") &&
				(typeof obj.ownerDocument ==="object");
		}
	}
	this.setType = function() {
		if(!this.element) {
			throw "Error (Inline Assessment): You can't set the type before there is an element defined.";
			return false;
		} else {
			this.type = this.element.getAttribute("type");
		}
		var inputElementString = (this.allTypes[this.type])?this.allTypes[this.type]:"<span>Inline assessment input elements undefined. Please define them before using this tool.</span>";
		var DOMNodesCreate = $("<div>"+inputElementString+"</div>");
		this.DOMNodes = DOMNodesCreate;
		return this.type;
	}
	this.emptyElement = function() {
		if(this.element) {
			var loopLimit = 1000;
			var loopCount = 0;
			if(this.element.children != undefined) {
				while(this.element.children.length > 0 && loopCount < loopLimit) {
					this.element.removeChild(this.element.children[0]);
					loopCount++;
				}
			} else
				throw "Error (Inline Assessment): element.children undefined. element must be invlid DOM (for instance: it could be a text node instead of an element node)";
		}
		return true;
	};
	this.display = function() {
		this.emptyElement();
		if( this.DOMNodes ) {
			for(var i=0; i < this.DOMNodes.length; i++)
				this.element.appendChild( this.DOMNodes[i] );
		} else {
			throw "Error (Inline Assessment): the intended DOM elements are invalid.";
			return false;
		}
		return this.element;
	};
	
	this.setElement( elementArg );

	if(!this.element) {
		if(!this.setElement( elementArg )) {
			if(!this.element || this.element === undefined) {
				throw "Error (Inline Assessment): element not specified.";
				return false;
			}
			//throw "Error (Inline Assessment): failed creating element input.";
			//return false;
		}
	}
	console.log(this);
	return this;
}
InlineAssessment.prototype.getId = function() { return id; };
InlineAssessment.prototype.getType = function() { return type; };
InlineAssessment.prototype.getElement = function() { return element; };

var assessmentElements;
$(document).ready(function(){
	assessmentElements = $("INLINE_ASSESSMENT");
	for(var a=0; a < assessmentElements.length; a++) {
		assessmentElements[a] = new InlineAssessment(assessmentElements[a]);
	}
});